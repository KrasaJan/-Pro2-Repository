## Cvičení

[cvičení pondělí 11:35](https://github.com/milankostak/PGRF1-2020/tree/master/src/pondeli_11_35_c06)

[cvičení středa 12:25](https://github.com/milankostak/PGRF1-2020/tree/master/src/streda_12_25_c01)

[cvičení středa 17:25](https://github.com/milankostak/PGRF1-2020/tree/master/src/streda_17_25_c02)


## Testy

1. test - 4. týden 21. října (středeční) a 26. října (pondělní)
2. test - PŘEDBĚŽNĚ 8. týden 18. listopadu (středeční) a 16. listopadu (pondělní)
3. test - PŘEDBĚŽNĚ 11./12. týden 9./16. prosince (středeční) a 7./14. prosince (pondělní)


## Projekty

1. projekt - 5. týden 28. října (středeční) a 31. října (pondělní)
2. projekt - PŘEDBĚŽNĚ 18. listopadu (středeční) a 16. listopadu (pondělní)
3. projekt - zatím neurčeno, někdy na konci semestru; pravděpodobně koncem 11. týdne (13. prosince)
