package cz.uhk.fim.pgrf1.app;

import cz.uhk.fim.pgrf1.controller.Controller2D;
import cz.uhk.fim.pgrf1.view.Window;

import javax.swing.*;

public class AppStart {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Window window = new Window();
            new Controller2D(window.getPanel());
            window.setVisible(true);
        });
    }

}
