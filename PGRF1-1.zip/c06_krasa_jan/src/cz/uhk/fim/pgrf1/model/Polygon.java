package cz.uhk.fim.pgrf1.model;

import cz.uhk.fim.pgrf1.rasterize.LineRasterizer;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Polygon {

    private final List<cz.uhk.fim.pgrf1.model.Point> points;
    private int color;


    public Polygon() {
        this(new ArrayList<>());
    }

    public Polygon(List<cz.uhk.fim.pgrf1.model.Point> points) {
        this(points, Color.GREEN.getRGB());
    } //Change color

    public Polygon(int color) {
        this(new ArrayList<>());
        this.color = color;
    }

    public Polygon(List<cz.uhk.fim.pgrf1.model.Point> points, int color) {
        this.points = points;
        this.color = color;
    }

    public void addPoint(cz.uhk.fim.pgrf1.model.Point point) {
        addPoints(point);
    }

    private void addPoints(cz.uhk.fim.pgrf1.model.Point... pointsToAdd) { // java varargs
        points.addAll(Arrays.asList(pointsToAdd.clone()));
    }

//    public void removePoint(Point point) {
//        removePoints(point);
//    }

//    private void removePoints(Point... pointsToRemove) {
//        points.removeAll(Arrays.asList(pointsToRemove));
//    }

    public void removeALL() {
        points.clear();
    }

    public void rasterize(LineRasterizer filledLineRasterizer, Color color) {
        for (int i = 0; i < points.size() - 1; i++) {
            Line line = new Line(this.getPoint(i), this.getPoint(i+1), color.getRGB());
            filledLineRasterizer.rasterize(line);
        }
    }

    public Point getPoint(int i) {
        return this.points.get(i);
    }

    public int getSize() {
        return this.points.size();
    }

    public void setPoint(int i, int newX, int newY) {
        this.points.get(i).setX(newX);
        this.points.get(i).setY(newY);
    }
}
