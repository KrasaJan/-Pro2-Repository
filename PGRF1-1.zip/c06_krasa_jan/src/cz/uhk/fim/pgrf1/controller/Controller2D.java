package cz.uhk.fim.pgrf1.controller;

import cz.uhk.fim.pgrf1.rasterize.DashedLineRasterizer;
import cz.uhk.fim.pgrf1.rasterize.FilledLineRasterizer;
import cz.uhk.fim.pgrf1.rasterize.LineRasterizer;
import cz.uhk.fim.pgrf1.rasterize.Raster;
import cz.uhk.fim.pgrf1.model.Point;
import cz.uhk.fim.pgrf1.model.Polygon;
import cz.uhk.fim.pgrf1.view.Panel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Controller2D {

    private final Panel panel;
    private final Raster raster;
    private final LineRasterizer dashedLineRasterizer;
    private final LineRasterizer filledLineRasterizer;

    private int mx, my, mx2, my2, closestPoint;
    private Polygon polygon = new Polygon();
    private boolean leftMouseButton = false, rightMouseButton = false;      //Used for dragging.

    private int outOfBoundsX(int x) {
        if (x < 0) {x = 0;}
        if (x > raster.getWidth()-1) {x = raster.getWidth()-1;}
        return x;
    }   //Checks if the x coordinate is outside of the window. If so sets it in.

    private int outOfBoundsY(int y) {
        if (y < 0) {y = 0;}
        if (y > raster.getHeight()-1) {y = raster.getHeight()-1;}
        return y;
    }   //Checks if the y coordinate is outside of the window. If so sets it in.

    private void closestPoint(int mx, int my) {
        if (polygon.getSize() >= 1) {
            double sqDifference, a = 100000;    //Distance is unlikely to be bigger.
            closestPoint = 0;               //Index of closest point

            for (int i = 0; i < polygon.getSize(); i++) {
                sqDifference = Math.sqrt(((mx - polygon.getPoint(i).getX()) * (mx - polygon.getPoint(i).getX()) +
                        (my - polygon.getPoint(i).getY()) * (my - polygon.getPoint(i).getY())));
                if (sqDifference < a) {
                    a = sqDifference;
                    closestPoint = i;
                }       //Using Pythagoras's theorem computing the distance between saved points. Saves the smaller distance and index of said point.
            }
        }
    }  //Gives index of closest point relative to mouse.

    public Controller2D(Panel panel) {
        this.panel = panel;
        this.raster = panel.getRaster();

        dashedLineRasterizer = new DashedLineRasterizer(raster);
        filledLineRasterizer = new FilledLineRasterizer(raster);
        initListeners();

        JLabel instructions = new JLabel("Left click for drawing lines. Right click for changing the position of the closest point. " +
                "Press c to reset the board.");
        instructions.setForeground(Color.white);
        panel.add(instructions);

    }  //Initiates listeners and rasterizers, adds controls.

    private void initListeners() {
        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getButton() == 1) {               //If left click.
                    leftMouseButton = true;
                    if (polygon.getSize() == 0) {
                        mx = outOfBoundsX(e.getX());
                        my = outOfBoundsY(e.getY());
                        polygon.addPoint(new Point(mx, my));
                    }
                }
                if (e.getButton() == 3) {               //If right click.
                    rightMouseButton = true;
                }
            }       //Saves the first point. Remembers which button was pressed.

            @Override
            public void mouseReleased(MouseEvent e){
                if (e.getButton() == 1) {
                    mx2 = outOfBoundsX(e.getX());
                    my2 = outOfBoundsY(e.getY());
                    raster.clear();
                    polygon.rasterize(filledLineRasterizer, Color.WHITE);
                    filledLineRasterizer.rasterize(polygon.getPoint(0).getX(), polygon.getPoint(0).getY(), mx2, my2, Color.WHITE);
                    filledLineRasterizer.rasterize(polygon.getPoint(polygon.getSize() - 1).getX(), polygon.getPoint(polygon.getSize() - 1).getY(),
                            mx2, my2, Color.WHITE);
                    polygon.addPoint(new Point(mx2, my2));
                    leftMouseButton = false;
                    rightMouseButton = false;
                }
            }       //At release clears the board, re-draws saved lines, adds 2 new and saves new point.
        });

        panel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                mx2 = outOfBoundsX(e.getX());
                my2 = outOfBoundsY(e.getY());
                if (leftMouseButton) {                  //If left click.
                    raster.clear();
                    polygon.rasterize(filledLineRasterizer, Color.WHITE);
                    dashedLineRasterizer.rasterize(polygon.getPoint(0).getX(), polygon.getPoint(0).getY(), mx2, my2, Color.RED);
                    dashedLineRasterizer.rasterize(polygon.getPoint(polygon.getSize() - 1).getX(), polygon.getPoint(polygon.getSize() - 1).getY(), mx2, my2, Color.RED);
                }   //Whilst dragging clears the board, re-draws saved lines and adds 2 new dashed ones.

                if (rightMouseButton) {                   //If right click.
                    closestPoint(mx2, my2);
                    polygon.setPoint(closestPoint, mx2, my2);
                    raster.clear();
                    //Draws the line between saved points. Does not draw a line between the first and the last.
                    polygon.rasterize(filledLineRasterizer, Color.WHITE);
                    //Draws line between First and Last.
                    filledLineRasterizer.rasterize(polygon.getPoint(0).getX(), polygon.getPoint(0).getY(),
                            polygon.getPoint(polygon.getSize() - 1).getX(), polygon.getPoint(polygon.getSize() - 1).getY(), Color.WHITE);
                }  //Whilst dragging changes position of closest point.
            }
        });

        panel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_C) {
                    System.out.println("C");
                    raster.clear();
                    polygon.removeALL();
                }
            }       //If "c" key is pressed, clear the board and delete saved polygon.
        });
    }

}
