package cz.uhk.fim.pgrf1.rasterize;

import java.awt.*;

public class DashedLineRasterizer extends LineRasterizer { //Done Uses Trivial Algorithm

    public DashedLineRasterizer(Raster raster) {
        super(raster);
    }

    @Override //Rasterize using Trivial algorithm. - advantages: simple.
    //Disadvantages: using float, thus is slow. Need float support on hardware => may not work on simple HW.
    public void rasterize(int x1, int y1, int x2, int y2, Color color) {
        boolean draw = true;
        int counter = 0;
        //In Analytic geometry we can illustrate a line using this formula: y = k*x + q
        float k = (y2 - y1) / (float) (x2 - x1);            //Computes the slope.
        float q = y1 - k * x1;                              //Computes y-itercept.
        System.out.println(k);

        if ((-1 < k)&&(k < 1)) {                            //Determines whether x or y is the leading axis.
            if (x1 > x2) {
                int x = x2;
                x2 = x1;
                x1 = x;
            }                              //Exchanges coordinates.
            for (int x = x1; x <= x2; x++) {                //X is the leading axis
                int y = (int) (k * x + q);
                if (draw) {raster.setPixel(x, y, color.getRGB());}      //The Dashed effect achieved through simple up to 10 counting.
                counter++;
                if (counter%10 == 0) {draw = !draw;}
                    if ((x == x2)&&(y == y2)&&(!draw)) {    //In the case of Dashed Line ending with an empty space revisit last 5 points and colours them.
                        for (int d = 0; d < 5; d++ ) {
                        raster.setPixel(x, Math.round(y), color.getRGB());
                        x--;
                        y = (int) (k * x + q);
                    }
                    }
            }
        } else {
            if (y1 > y2) {
                int y = y2;
                y2 = y1;
                y1 = y;
            }                              //Exchanges coordinates.
            for (int y = y1; y <= y2; y++) {                //Y is the leading axis
                int x;
                if (x1 != x2) {x = (int) ((y - q) / k);}            //We can have a vertical line in which case we would divide by zero.
                else {x = x1;}
                if (draw) {raster.setPixel(x, y, color.getRGB());}      //The Dashed effect achieved through simple up to 10 counting.
                counter++;
                if (counter%10 == 0) {draw = !draw;}
                    if ((x == x2)&&(y == y2)&&(!draw)) {    //In the case of Dashed Line ending with an empty space revisit last 5 points and colours them.
                        for (int d = 0; d < 5; d++ ) {
                        raster.setPixel(Math.round(x), y, color.getRGB());
                        y--;
                        if (x1 != x2) x = (int) ((y - q) / k);
                    }
                    }
            }
        }
    }

}

