package cz.uhk.fim.pgrf1.rasterize;

import java.awt.*;

public class FilledLineRasterizer extends LineRasterizer {

    public FilledLineRasterizer(Raster raster) {
        super(raster);
    }

    @Override //Rasterize using Bresenham's algorithm. - advantages: using just whole numbers, addition, extraction and multiplication by 2,
    //as such is fast and capable of running on simple hardware.
    public void rasterize(int x1, int y1, int x2, int y2, Color color) {

        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int p = 2 * dy - dx;                    //Prediction - used for determining whether the secondary coordinates will change or not.
        int x = x1, y = y1;
        int moveX, moveY;                       //Changes X axis left to right, and Y axis down to top.

        if (x1 < x2) moveX = 1; else moveX = -1; //Changes the semi-quadrant. X+ draws right, X- draws left.
        if (y1 < y2) moveY = 1; else moveY = -1; //Changes the semi-quadrant. Y+ draws bottom, Y- draws top.

        if (Math.abs(dx) >= Math.abs(dy)) {             //Determines which is the main axis. - Dx - x is main; Dy - y is main.
            for (x = x1; x <= x2; x = x + moveX) {      //Cycle for creating the line, works at right side.
                raster.setPixel(x, y, color.getRGB());
                if (p >= 0) {
                    y = y + moveY;
                    p = p + 2 * dy - 2 * dx;
                } else {
                    p = p + 2 * dy;
                }
            }
            for (x = x1; x >= x2; x = x + moveX) {      //Cycle for creating the line, works at left side.
                raster.setPixel(x, y, color.getRGB());
                if (p >= 0) {
                    y = y + moveY;
                    p = p + 2 * dy - 2 * dx;
                } else {
                    p = p + 2 * dy;
                }
            }
        } else {
            for (y = y1; y <= y2; y = y + moveY) {      //Cycle for creating the line, works at down side.
                raster.setPixel(x, y, color.getRGB());
                if(x1 !=x2) if (p >= 0) {               //If given a vertical line, just go through the setPixel.
                    x = x + moveX;
                    p = p + 2 * dx - 2 * dy;
                } else {
                    p = p + 2 * dx;
                }
            }
            for (y = y1; y >= y2; y = y + moveY) {      //Cycle for creating the line, works at top side.
                raster.setPixel(x, y, color.getRGB());
                if(x1 !=x2) if (p >= 0) {               //If given a vertical line, just go through the setPixel.
                    x = x + moveX;
                    p = p + 2 * dx - 2 * dy;
                } else {
                    p = p + 2 * dx;
                }
            }
        }
    }

}