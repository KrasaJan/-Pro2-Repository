package model3d;

import transforms.Point3D;

import java.awt.*;

public class Octahedron extends Solid {

    public Octahedron() {

        vertexBuffer.add(new Vertex(new Point3D(1, 0, 1), Color.WHITE));
        vertexBuffer.add(new Vertex(new Point3D(1, 0, -1), Color.WHITE));
        vertexBuffer.add(new Vertex(new Point3D(-1, 0, 1), Color.WHITE));
        vertexBuffer.add(new Vertex(new Point3D(-1, 0, -1), Color.WHITE));

        vertexBuffer.add(new Vertex(new Point3D(0, 1, 0), Color.WHITE));
        vertexBuffer.add(new Vertex(new Point3D(0, -1, 0), Color.WHITE));

        addIndices(0, 1, 2, 3, 0, 2, 1, 3);
        addIndices(0, 4, 1, 4, 2, 4, 3, 4);
        addIndices(0, 5, 1, 5, 2, 5, 3, 5);
    }

}
