package model3d;

import transforms.Cubic;
import transforms.Mat4;
import transforms.Point3D;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Cubic3D extends Solid {

    public Cubic3D(Mat4 type, Color color) {

        //Control Points
        List<Point3D> points =  new ArrayList<>();
        points.add(new Point3D(0,1,0));
        points.add(new Point3D(-0.5,-0.8,0.3));
        points.add(new Point3D(0.3,0.8,-0.5));
        points.add(new Point3D(0,-1,0));

        Cubic cubic = new Cubic(type, points.get(0), points.get(1), points.get(2), points.get(3));

        //Computing points and saving them to VertexBuffer.
        for (int i = 0; i < 50; i++) {
            Point3D point = cubic.compute((double) i / 50);
            vertexBuffer.add(new Vertex(point, color));
            if (i != 0) {
                indexBuffer.add(i - 1);
                indexBuffer.add(i);
            }
        }

    }

}
