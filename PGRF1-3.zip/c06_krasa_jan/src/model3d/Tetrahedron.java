package model3d;

import transforms.Point3D;

import java.awt.*;

public class Tetrahedron extends Solid {

    public Tetrahedron() {

        vertexBuffer.add(new Vertex(new Point3D(-1, -1, 1), Color.YELLOW));
        vertexBuffer.add(new Vertex(new Point3D(1, -1, 1), Color.YELLOW));
        vertexBuffer.add(new Vertex(new Point3D(0, -1, -1), Color.YELLOW));
        vertexBuffer.add(new Vertex(new Point3D(0, 1, 0), Color.YELLOW));

        addIndices(0, 1, 1, 2, 2, 0);
        addIndices(0, 3, 1, 3, 2, 3);
    }
}
