package model3d;

import transforms.Point3D;

import java.awt.*;

public class Axis extends Solid {

    public Axis() {
        transformable = false;

        vertexBuffer.add(new Vertex(new Point3D(0, 0, 0)));
        vertexBuffer.add(new Vertex(new Point3D(2, 0, 0), Color.RED));
        vertexBuffer.add(new Vertex(new Point3D(0, 2, 0), Color.BLUE));
        vertexBuffer.add(new Vertex(new Point3D(0, 0, 2), Color.GREEN));

        addIndices(0, 1);
        addIndices(0, 2);
        addIndices(0, 3);
    }

}
