package model3d;

import transforms.Point3D;

import java.awt.*;

public class Vertex {

    private Point3D point;
    private Color color;

    public Vertex(Point3D point) {
        this.point = point;
        this.color = Color.YELLOW;
    }

    public Vertex(Point3D point, Color color) {
        this.point = point;
        this.color = color;
    }

    public Point3D getPoint() {
        return point;
    }

    public Color getColor() {
        return color;
    }

    public void setPoint(Point3D point) {
        this.point = point;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}
