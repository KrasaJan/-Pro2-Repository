package model3d;

import transforms.Mat4;
import transforms.Mat4Identity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class Solid {

    final List<Vertex> vertexBuffer = new ArrayList<>();
    final List<Integer> indexBuffer = new ArrayList<>();
    private Mat4 model = new Mat4Identity();
    boolean transformable = true;

    final void addIndices(Integer... indices) {
        indexBuffer.addAll(Arrays.asList(indices));
    }

    public void setModel(Mat4 model) {
        this.model = model;
    }

    public List<Integer> getIndexBuffer() {
        return indexBuffer;
    }

    public List<Vertex> getVertexBuffer() {
        return vertexBuffer;
    }

    public boolean getTransformable() {return transformable; }

    public Mat4 getModel() {
        return model;
    }

}
