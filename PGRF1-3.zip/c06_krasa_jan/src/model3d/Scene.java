package model3d;

import java.util.ArrayList;
import java.util.List;

public class Scene {

    public Scene() {
        solids = new ArrayList<>();
    }

    private final List<Solid> solids;

    public List<Solid> getSolids() {
        return solids;
    }

    public void addSolid(Solid solid) {
        solids.add(solid);
    }

    public void removeSolid(Solid solid) {
        solids.remove(solid);
    }

}
