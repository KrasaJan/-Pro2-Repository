package controller;

import model3d.*;
import rasterize.Raster;
import renderer.GPURenderer;
import renderer.Renderer3D;
import view.Panel;
import transforms.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Controller3D {

    private final GPURenderer renderer;
    private final Raster raster;

    private final Scene mainScene;
    private final Solid cube, tetra, octa;
    private final Solid bezier, coons, ferguson;
    private Mat4 scale;
    private final Mat4 view, orthoPro, perspPro;
    private Camera camera;

    private int endX, endY, ogX, ogY;
    private final double scaleUp = 1.1, scaleDown = 0.9, step = 0.5;
    private boolean leftMB, rightMB, middleMB;

    private JRadioButton JView, JCamera, JOrtho, JPersp;
    private JCheckBox JCube, JTetra, JOcta;
    private JCheckBox JBezier, JCoons, JFergun;
    private JLabel viewInstructions, camInstructions1, camInstructions2;

    public Controller3D(Panel panel) {
        this.raster = panel.getRaster();
        initListeners(panel);

        renderer = new Renderer3D(raster);

        mainScene = new Scene();
        mainScene.addSolid(new Axis());
        mainScene.addSolid(cube = new Cube());
        mainScene.addSolid(tetra = new Tetrahedron());
        mainScene.addSolid(octa = new Octahedron());
        bezier = new Cubic3D(Cubic.BEZIER, Color.CYAN);
        coons = new Cubic3D(Cubic.COONS, Color.MAGENTA);
        ferguson = new Cubic3D(Cubic.FERGUSON, Color.GRAY);

        Vec3D e = new Vec3D(8, -5, 2);
        Vec3D v = new Vec3D(-8, 5, -2);
        Vec3D u = new Vec3D(0, 0, 1);
        view = new Mat4ViewRH(e, v, u);

        perspPro = new Mat4PerspRH(
                Math.PI / 3,
                raster.getHeight() / (float) raster.getWidth(),
                0.1,
                30
        );

        orthoPro = new Mat4OrthoRH(
                20,
                10,
                0,
                30
        );

        initUI(panel);
        reInitiate();
        display();

    }

    /* Sets appropriate instructions, resets camera and solids. */
    private void reInitiate() {
        if(JCamera.isSelected()) {
            camInstructions1.setVisible(true);
            camInstructions2.setVisible(true);
            viewInstructions.setVisible(false);
        } else {
            camInstructions1.setVisible(false);
            camInstructions2.setVisible(false);
            viewInstructions.setVisible(true);
        }

        Mat4 model = new Mat4Identity();
        for (Solid solid : mainScene.getSolids()) { solid.setModel(model); }

        camera = new Camera()
                .withPosition(new Vec3D(3, 3, 3))
                .withAzimuth(Math.toRadians(225))
                .withZenith(Math.toRadians(-30))
                .withFirstPerson(true);

    }

    /* Sets view and projection matrices, sets curves model matrices based on Octahedron's one. Displays the scene */
    private void display() {

        raster.clear();

        if (JCamera.isSelected()) { renderer.setView(camera.getViewMatrix()); }
        if (JView.isSelected()) { renderer.setView(view); }
        if (JPersp.isSelected()) { renderer.setProjection(perspPro); }
        if (JOrtho.isSelected()) { renderer.setProjection(orthoPro); }
        if (JBezier.isSelected()) { bezier.setModel(octa.getModel()); }
        if (JCoons.isSelected()) { coons.setModel(octa.getModel()); }
        if (JFergun.isSelected()) { ferguson.setModel(octa.getModel()); }
        renderer.draw(mainScene);

    }

    private void initListeners(Panel panel) {

        panel.addMouseListener(new MouseAdapter() {

            @Override
            /* Gets the coordinates of a click and remembers the button. */
            public void mousePressed(MouseEvent e) {
                if (e.getButton() == 1) { leftMB = true; }
                if (e.getButton() == 2) { middleMB = true; }
                if (e.getButton() == 3) { rightMB = true; }
                endX = e.getX();
                endY = e.getY();
            }

            @Override
            /* Resets pressed button. */
            public void mouseReleased(MouseEvent e) {
                leftMB = false;
                middleMB = false;
                rightMB = false;
            }

        });

        panel.addMouseMotionListener(new MouseAdapter() {

            @Override
            /* Computes the difference of x,y coordinates, if LMB moves camera, if MMB moves solids, if RMB rotes them. */
            public void mouseDragged(MouseEvent e) {
                ogX = endX;
                ogY = endY;
                endX = e.getX();
                endY = e.getY();
                int moveX = endX - ogX;
                int moveY = endY - ogY;

                if (leftMB) {
                    camera = camera.addAzimuth((double) - moveX * Math.PI / 1200);
                    camera = camera.addZenith((double) - moveY * Math.PI / 1200);
                }
                if (middleMB) {
                    Mat4 transl = new Mat4Transl((double)moveX/100,(double)moveY/100,0);
                    computeModel(transl);
                }
                if (rightMB) {
                    Mat4 rot;
                    rot = new Mat4RotXYZ(0, + moveY * Math.PI / 720, moveX * Math.PI / 720);
                    if (e.isControlDown()) {
                        rot = new Mat4RotX(moveX * Math.PI/720);
                    }
                    if (e.isShiftDown()) {
                        rot = new Mat4RotY(moveY * Math.PI/720);
                    }
                    if (e.isAltDown()) {
                        rot = new Mat4RotZ(moveX * Math.PI/720);
                    }
                    computeModel(rot);
                }
                display();
            }

        });

        panel.addMouseWheelListener(new MouseAdapter() {
            @Override
            /* Moves camera up/down, scales solids. */
            public void mouseWheelMoved(MouseWheelEvent e) {
                if (JCamera.isSelected()) {
                    if (e.isControlDown()){
                        if (e.getWheelRotation() < 0) {
                            scale = new Mat4Scale(scaleUp);
                        } else {
                            scale = new Mat4Scale(scaleDown);
                        }
                        computeModel(scale);
                    } else {
                        if (e.getWheelRotation() < 0) {
                            camera = camera.up(step);
                        } else {
                            camera = camera.down(step);
                        }
                    }
                } else {
                    if (e.getWheelRotation() < 0) {
                        scale = new Mat4Scale(scaleUp);
                    } else {
                        scale = new Mat4Scale(scaleDown);
                    }
                    computeModel(scale);
                }
                display();
            }
        });

        panel.addKeyListener(new KeyAdapter() {
            @Override
            /* Sets WSAD movement + R for reset button */
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_R) { reInitiate(); }
                if (e.getKeyCode() == KeyEvent.VK_W) { camera = camera.forward(step); }
                if (e.getKeyCode() == KeyEvent.VK_S) { camera = camera.backward(step); }
                if (e.getKeyCode() == KeyEvent.VK_A) { camera = camera.left(step); }
                if (e.getKeyCode() == KeyEvent.VK_D) { camera = camera.right(step); }
                display();
            }
        });

    }

    /* Changes the model matrix of active solids. */
    private void computeModel(Mat4 mat) {
        if (JCube.isSelected()) { cube.setModel(cube.getModel().mul(mat)); }
        if (JTetra.isSelected()) { tetra.setModel(tetra.getModel().mul(mat)); }
        if (JOcta.isSelected()) { octa.setModel(octa.getModel().mul(mat)); }
    }

    /* Defines buttons and help labels. */
    private void initUI(Panel panel) {
        JToolBar tb = new JToolBar();
        tb.setFocusable(false);
        panel.add(tb);

        viewInstructions = new JLabel("Hold MMB to move the solids, RMB to rotate solids (CTRL, SHIFT, ALT + RMB to rotate along X, Y, Z respectively.(Red X, Blue Y, Green Z)). Scroll for Scaling of solids. R to Re-initiate original state of solids.");
        viewInstructions.setForeground(Color.white);
        viewInstructions.setVisible(false);
        panel.add(viewInstructions);
        camInstructions1 = new JLabel("Hold LMB for moving the camera, MMB for moving solids, RMB to rotate solids (CTRL, SHIFT, ALT + RMB to rotate along X, Y, Z respectively (Red X, Blue Y, Green Z)).");
        camInstructions2 = new JLabel("WSAD to move the position of camera. Scroll to move up or down, CTRL + scroll to scale solids. R to Re-initiate original state of camera and solids.");
        camInstructions1.setForeground(Color.white); camInstructions2.setForeground(Color.white);
        camInstructions1.setVisible(true); camInstructions2.setVisible(true);
        panel.add(camInstructions1); panel.add(camInstructions2);

        createButtons(tb);
    }

    private void createButtons(JToolBar tb) {

        JView = new JRadioButton("View");
        JView.setFocusable(false);

        JCamera = new JRadioButton("Camera");
        JCamera.setFocusable(false);
        JCamera.setSelected(true);

        ButtonGroup viewModes = new ButtonGroup();
        viewModes.add(JView);
        viewModes.add(JCamera);

        JPersp = new JRadioButton("Perspective Projection");
        JPersp.setFocusable(false);
        JPersp.setSelected(true);

        JOrtho = new JRadioButton("Orthogonal Projection");
        JOrtho.setFocusable(false);

        ButtonGroup projModes = new ButtonGroup();
        projModes.add(JPersp);
        projModes.add(JOrtho);

        JCube = new JCheckBox("Cube");
        JCube.setFocusable(false);
        JCube.setSelected(true);

        JTetra = new JCheckBox("Tetrahedron");
        JTetra.setFocusable(false);
        JTetra.setSelected(true);

        JOcta = new JCheckBox("Octahedron");
        JOcta.setFocusable(false);
        JOcta.setSelected(true);

        JBezier = new JCheckBox("Bezier");
        JBezier.setFocusable(false);

        JCoons = new JCheckBox("Coons");
        JCoons.setFocusable(false);

        JFergun = new JCheckBox("Ferguson");
        JFergun.setFocusable(false);

        tb.add(JView);
        tb.add(JCamera);
        tb.add(JPersp);
        tb.add(JOrtho);
        tb.add(JCube);
        tb.add(JTetra);
        tb.add(JOcta);
        tb.add(JBezier);
        tb.add(JCoons);
        tb.add(JFergun);

        JView.addActionListener(e -> view());
        JCamera.addActionListener(e -> camera());
        JPersp.addActionListener(e -> persp());
        JOrtho.addActionListener(e -> ortho());
        JCube.addActionListener(e -> cube());
        JTetra.addActionListener(e -> tetra());
        JOcta.addActionListener(e -> octa());
        JBezier.addActionListener(e -> bezier());
        JCoons.addActionListener(e -> coons());
        JFergun.addActionListener(e -> ferguson());
    }

    private void cube() {
        if (JCube.isSelected()) {
            mainScene.addSolid(cube);
        } else {
            mainScene.removeSolid(cube);
        }
        display();
    }

    private void tetra() {
        if (JTetra.isSelected()) {
            mainScene.addSolid(tetra);
        } else {
            mainScene.removeSolid(tetra);
        }
        display();
    }

    private void octa() {
        if (JOcta.isSelected()) {
            mainScene.addSolid(octa);
        } else {
            mainScene.removeSolid(octa);
            mainScene.removeSolid(bezier);
            JBezier.setSelected(false);
            mainScene.removeSolid(coons);
            JCoons.setSelected(false);
            mainScene.removeSolid(ferguson);
            JFergun.setSelected(false);
        }
        display();
    }

    private void bezier() {
        if (JBezier.isSelected()) {
            if(JOcta.isSelected()) {
                mainScene.addSolid(bezier);
            } else {
                JBezier.setSelected(false);
            }
        } else {
            mainScene.removeSolid(bezier);
        }
        display();
    }

    private void coons() {
        if (JCoons.isSelected()) {
            if(JOcta.isSelected()) {
                mainScene.addSolid(coons);
            } else {
                JCoons.setSelected(false);
            }
        } else {
            mainScene.removeSolid(coons);
        }
        display();
    }

    private void ferguson() {
        if (JFergun.isSelected()) {
            if(JOcta.isSelected()) {
                mainScene.addSolid(ferguson);
            } else {
                JFergun.setSelected(false);
            }
        } else {
            mainScene.removeSolid(ferguson);
        }
        display();
    }

    private void view() {
        reInitiate();
        display();
    }

    private void camera() {
        reInitiate();
        display();
    }

    private void persp() {
        display();
    }

    private void ortho() {
        display();
    }

}
