package renderer;

import model3d.Scene;
import model3d.Solid;
import model3d.Vertex;
import rasterize.LineRasterizer;
import rasterize.LineRasterizerGraphics;
import rasterize.Raster;
import transforms.*;

import java.awt.*;
import java.util.List;
import java.util.Optional;

public class Renderer3D implements GPURenderer {

    private final Raster raster;
    private final LineRasterizer lineRasterizer;

    private Mat4 view, projection, transform;

    public Renderer3D(Raster raster) {
        this.raster = raster;
        lineRasterizer = new LineRasterizerGraphics(raster);
    }

    @Override
    /* Draws all solids from scene. */
    public void draw(Scene scene) {

        /* For every solid in the scene */
        for (Solid solid : scene.getSolids()) {
            List<Integer> ib = solid.getIndexBuffer();
            List<Vertex> vb = solid.getVertexBuffer();
            /* Prepares transform matrix, if the solid in question is Axis doesn't use the Model matrix. */
            transform = new Mat4Identity();
            if (solid.getTransformable()) {
                transform = transform.mul(solid.getModel()).mul(view).mul(projection);
            } else {
                transform = transform.mul(view).mul(projection);
            }
            /* Reads separate edges, transforms and rasterizes them */
            for (int i = 0; i < ib.size(); i += 2) {
                Integer index1 = ib.get(i);
                Integer index2 = ib.get(i + 1);
                Vertex vertex1 = vb.get(index1);
                Vertex vertex2 = vb.get(index2);

                transformLine(vertex1.getPoint(), vertex2.getPoint(), vertex2.getColor());
            }
        }
    }

    /**
     * Transforms, clips, dehomogenizes, sets raster coordinates and rasterizes the line.
     * @param a First point of the edge
     * @param b Second point of the edge
     * @param color Color for line
     */
    private void transformLine(Point3D a, Point3D b, Color color) {

        /* Transforms the points */
        a = a.mul(transform);
        b = b.mul(transform);

        /* Fast Clipping */
        if (clip(a)) return;
        if (clip(b)) return;

        /* Dehomogenization */
        Optional<Vec3D> dehomogA = a.dehomog();
        Optional<Vec3D> dehomogB = b.dehomog();
        if (dehomogA.isEmpty() || dehomogB.isEmpty()) return;
        Vec3D finalA = dehomogA.get();
        Vec3D finalB = dehomogB.get();

        /* Transformation into Window */
        finalA = transformToWindow(finalA);
        finalB = transformToWindow(finalB);

        /* Rasterization */
        lineRasterizer.rasterize(
                (int) Math.round(finalA.getX()),
                (int) Math.round(finalA.getY()),
                (int) Math.round(finalB.getX()),
                (int) Math.round(finalB.getY()),
                color
        );
    }

    /**
     * Clips all that is not within: x,y (-w;w) or z (0;w).
     * @param v homogenized point
     * @return true if clip
     */
    private boolean clip(Point3D v) {
        double x = v.getX();
        double y = v.getY();
        double z = v.getZ();
        double w = v.getW();

        return !(((x > -w) && (x < w)) && ((y > -w) && (y < w)) && ((z > 0) && (z < w)));
    }

    private Vec3D transformToWindow(Vec3D v) {
        return v.mul(new Vec3D(1,-1,1))
                .add(new Vec3D(1, 1, 0))
                .mul(new Vec3D(raster.getWidth() / 2.0, raster.getHeight() / 2.0, 1));
    }

    @Override
    public void setView(Mat4 view) {
        this.view = view;
    }

    @Override
    public void setProjection(Mat4 projection) {
        this.projection = projection;
    }

}
