package controller;

//import cz.uhk.fim.pgrf1.fill.PatternFill;
import fill.ScanLineFiller;
import fill.SeedFiller;
//import cz.uhk.fim.pgrf1.fill.BorderSeedFiller;
import model.Line;
import rasterize.DashedLineRasterizer;
import rasterize.FilledLineRasterizer;
import rasterize.LineRasterizer;
import rasterize.Raster;
import model.Board;
import model.Point;
import model.Polygon;
import view.Panel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Controller2D {

    private final Panel panel;
    private final Raster raster;
    private final LineRasterizer dashedLineRasterizer;
    private final LineRasterizer filledLineRasterizer;
    private final SeedFiller seedFiller;
//    private final BorderSeedFiller borderSeedFiller;
    private ScanLineFiller scanLineFiller;
//    private final PatternFill patternFill;

    private int mx, my, mx2, my2, closestPoint, closestPolygon, polygonCount = 1;
    private Polygon polygon = new Polygon();
    private final Board board = new Board();
    private boolean leftMouseButton = false, rightMouseButton = false;      //Used for dragging.

    private int outOfBoundsX(int x) {
        if (x < 0) {x = 0;}
        if (x > raster.getWidth()-1) {x = raster.getWidth()-1;}
        return x;
    }   //Checks if the x coordinate is outside of the window. If so sets it in.

    private int outOfBoundsY(int y) {
        if (y < 0) {y = 0;}
        if (y > raster.getHeight()-1) {y = raster.getHeight()-1;}
        return y;
    }   //Checks if the y coordinate is outside of the window. If so sets it in.

    private void closestPoint(int mx, int my) {
        if (polygon.getSize() >= 1) {
            double sqDifference, a = Double.MAX_VALUE;
            closestPoint = 0;               //Index of closest point
            closestPolygon = 0;

            for (int j = 0; j < board.getSize(); j++) {
                for (int i = 0; i < board.getPolygon(j).getSize(); i++) {
                    sqDifference = Math.sqrt(((mx - board.getPolygon(j).getPoint(i).getX()) * (mx - board.getPolygon(j).getPoint(i).getX()) +
                            (my - board.getPolygon(j).getPoint(i).getY()) * (my - board.getPolygon(j).getPoint(i).getY())));
                    if (sqDifference < a) {
                        a = sqDifference;
                        closestPoint = i;
                        closestPolygon = j;
                    }       //Using Pythagoras's theorem computing the distance between saved points. Saves the smaller distance and index of said point.
                }
            }
        }
    }  //Gives index of closest point relative to mouse.

    private void reInitiate() {
        raster.clear();
        for (int i = 0; i < board.getSize(); i++) {
            board.getPolygon(i).removeALL();
        }
        board.removeALL();
        polygonCount = 1;
        polygon.addPoint(new Point(0,0));
        board.addPolygon(polygon);
        scanLineFiller = new ScanLineFiller(filledLineRasterizer, board.getPolygon(0).getPoints());
    }

    public Controller2D(Panel panel) {
        this.panel = panel;
        this.raster = panel.getRaster();

        dashedLineRasterizer = new DashedLineRasterizer(raster);
        filledLineRasterizer = new FilledLineRasterizer(raster);
        seedFiller = new SeedFiller(raster);
//        borderSeedFiller = new BorderSeedFiller(raster);
        polygon.addPoint(new Point(0,0));
        board.addPolygon(polygon);
        scanLineFiller = new ScanLineFiller(filledLineRasterizer, board.getPolygon(0).getPoints());
        initListeners();

        JLabel instructions = new JLabel("Left click for drawing lines. Right click for changing the position of the closest point. " +
                "Press c to reset the board. Middle click for saving current polygon. Shift + left click for seed fill.");
        instructions.setForeground(Color.white);
        panel.add(instructions);

    }  //Initiates listeners and rasterizers, adds controls.

    private void initListeners() {
        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getButton() == 1) {               //If left click.
                    if (!e.isShiftDown()) {
                        leftMouseButton = true;
                        mx = outOfBoundsX(e.getX());
                        my = outOfBoundsY(e.getY());
                        if ((polygon.getPoint(0).getX() == 0) && ((polygon).getPoint(0).getY() == 0)) {
                            polygon.setPoint(0, mx, my);
                        } //polygon gets initiated with point of 0,0. Rewrites it.
                        polygon.addPoint(new Point(mx, my));
                    }
                }
                if (e.getButton() == 2) {               //If middle click.
                    polygon = new Polygon();
                    polygon.addPoint(new Point(0,0));
                    polygonCount++;
                    board.addPolygon(polygon);
                }
                if (e.getButton() == 3) {               //If right click.
                    rightMouseButton = true;
                }
            }

            @Override
            public void mouseReleased(MouseEvent e){
                if (!e.isShiftDown()) {
                    if (e.getButton() == 1) {
                        mx2 = outOfBoundsX(e.getX());
                        my2 = outOfBoundsY(e.getY());
                        polygon.setPoint(polygon.getSize() - 1, mx2, my2);
                        raster.clear();
                        for (int i = 0; i <= polygonCount - 1; i++) {
                            board.getPolygon(i).rasterize(filledLineRasterizer, board.passColor(i));
                        }
                        scanLineFiller.fill();
//                      if (polygonCount > 1) { scanLineFiller.cutPoints(board.getPolygon(polygonCount-1)); }
                        leftMouseButton = false;
                        rightMouseButton = false;
                    }
                }
            }       //At release clears the board, re-draws saved lines, adds 2 new and saves new point.

            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.isShiftDown()) {
//                    if (leftMouseButton) {
                        if(raster.getPixel(e.getX(), e.getY()) != -8582646) {
                            seedFiller.setSeed(new Point(e.getX(), e.getY()));
                            seedFiller.setFillColor(0x7d0a0a);
                            seedFiller.fill();
                        }
//                    }
//                    if (rightMouseButton) {
//                        borderSeedFiller.setSeed(new Point(e.getX(), e.getY()));
//                        borderSeedFiller.setFillColor(0x7d0c0c);
//                        borderSeedFiller.setBorderColor(Color.GRAY.getRGB());
//                        borderSeedFiller.fill();
//                    }
                }
            }

        });

        panel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                mx2 = outOfBoundsX(e.getX());
                my2 = outOfBoundsY(e.getY());
                if (leftMouseButton) {                  //If left click.
                    polygon.setPoint(polygon.getSize() - 1, mx2, my2);
                    raster.clear();
                    for (int i = 0; i <= polygonCount - 1; i++) {
                        board.getPolygon(i).rasterize(filledLineRasterizer, board.passColor(i));
                    }
                    scanLineFiller.fill();
                    dashedLineRasterizer.rasterize(polygon.getPoint(0).getX(), polygon.getPoint(0).getY(), mx2, my2, Color.RED);
                    dashedLineRasterizer.rasterize(new Line(polygon.getPoint(polygon.getSize() - 2), polygon.getPoint(polygon.getSize() - 1), 0xFF0000));
                }   //Whilst dragging clears the board, re-draws saved lines and adds 2 new dashed ones.

                if (rightMouseButton) {                   //If right click.
                    closestPoint(mx2, my2);
                    board.getPolygon(closestPolygon).setPoint(closestPoint, mx2, my2);
                    raster.clear();
                    //Draws the lines between saved points.
                    for (int i = 0; i <= polygonCount - 1; i++) {
                        board.getPolygon(i).rasterize(filledLineRasterizer, board.passColor(i));
                    }
                    scanLineFiller.fill();
                }  //Whilst dragging changes position of closest point.
            }
        });

        panel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_C) {
                    reInitiate();
                }
            }       //If "c" key is pressed, clear the board and delete saved polygon.
        });
    }

}



//
//    private int mx, my;
//
//    public Controller2D(Panel panel) {
//        this.panel = panel;
//        this.raster = panel.getRaster();
//
//        trivialLineRasterizer = new TrivialLineRasterizer(raster);
//        patternFill = new PatternFill() {
//            @Override
//            public int paint(int x, int y) {
//                if (x % 2 == 0) return 0x00ff00;
//                else return 0xffff00;
//            }
//        };
//        patternFill = (x, y) -> {
//            if (x % 2 == 0) return 0x00ff00;
//            else return 0xffff00;
//        };
