package fill;

@FunctionalInterface
public interface PatternFill {

    int paint(int x, int y);

}
