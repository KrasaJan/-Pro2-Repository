package fill;

import model.Point;
import rasterize.Raster;

public class SeedFiller implements Filler {

    private final Raster raster;

    private int backgroundColor;
    private int fillColor;
    private Point seed;
//    private PatternFill patternFill;

    public SeedFiller(Raster raster) {
        this.raster = raster;
        fillColor = 0xffffff;
    }

    public void setSeed(Point seed) {
        this.seed = seed;
        backgroundColor = raster.getPixel(seed.getX(), seed.getY());
    }

    public void setFillColor(int fillColor) {
        this.fillColor = fillColor;
    }

//    public void setPatternFill(PatternFill patternFill) {
//        this.patternFill = patternFill;
//    }



    @Override
    public void fill() {
        seedFill(seed.getX(), seed.getY());
    }

    private boolean rasterEdge(int x, int y) {
        int rasterX = raster.getWidth();
        int rasterY = raster.getHeight();

        if ((x == 0)||(x == rasterX-1)) return true;
        if ((y == 0)||(y == rasterY-1)) return true;
        return false;
    }

//  VM options -Xss80m
    private void seedFill(int x, int y) {
        if (raster.getPixel(x, y) == backgroundColor) {
            raster.setPixel(x, y, fillColor);
//            raster.setPixel(x, y, patternFill.paint(x, y));
            if (!rasterEdge(x,y)) seedFill(x + 1, y); // rightwards
            if (!rasterEdge(x,y)) seedFill(x - 1, y); // leftwards
            if (!rasterEdge(x,y)) seedFill(x, y + 1); // downwards
            if (!rasterEdge(x,y)) seedFill(x, y - 1); // upwards
        }
    }

}
