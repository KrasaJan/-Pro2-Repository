package fill;

import model.Edge;
import model.Line;
import model.Point;
import rasterize.LineRasterizer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScanLineFiller implements Filler {

    private final LineRasterizer lineRasterizer;

    private final List<Point> points;
    private final int fillColor;
    private final int borderColor;

    public ScanLineFiller(LineRasterizer lineRasterizer, List<Point> points, int fillColor, int borderColor) {
        this.lineRasterizer = lineRasterizer;
        this.points = points;
        this.fillColor = fillColor;
        this.borderColor = borderColor;
    }

    public ScanLineFiller(LineRasterizer lineRasterizer, List<Point> points) {
        this(lineRasterizer, points, 0x00ffff, 0x0000ff);
    }

    //TODO Receives correct polygon, correctly saves edges. Interception does not work. ¯\_(ツ)_/¯ No time left.
//    public List<Point> cutPoints(Polygon polygon) {
//        List<Point> clippedPoints = new ArrayList<>();
//        List<Edge> edges = new ArrayList<>();
//        Edge edge;
//        Point point;
//        int i, j = 0;
//        /**Clipping polygon.*/
//        for (i = 0; i < points.size()-1; i++) {
//            edge = new Edge(points.get(i), points.get(i+1));
//            edges.add(j++, edge);
//        }
//        edge = new Edge(points.get(0), points.get(i));
//        edges.add(j, edge);
//        /**Clipped polygon.*/
//        for (i = 0; i < edges.size(); i++) {
//            for (j = 0; j < polygon.getSize()-1; j++) {
//                point = edges.get(i).getIntersection(polygon.getPoint(j), polygon.getPoint(j + 1));
//                if (point !=null) {clippedPoints.add(point);}
//                }
//            point = edges.get(i).getIntersection(polygon.getPoint(0), polygon.getPoint(j));
//            if (point !=null) {clippedPoints.add(point);}
//        }
//        System.out.println("Clipped: " + clippedPoints.size() + " Edges: " + edges.size() + " Polygon Points: " + polygon.getSize());
//        for (i = 0; i < clippedPoints.size(); i++) {
//            System.out.println("Level i: " + i + " X: " + clippedPoints.get(i).getX() + " Y: "+ clippedPoints.get(i).getY());
//        }
//        return null;
//    }

    @Override
    public void fill() {
        List<Edge> edges = new ArrayList<>();
        Edge edge;
        int i, j = 0;

        //Adds all non horizontal edges from the Points list and orientates them.
        for (i = 0; i < points.size()-1; i++) {
            edge = new Edge(points.get(i), points.get(i+1));
            if (!edge.isHorizontal()) { edges.add(j++, edge); }
        }
        edge = new Edge(points.get(0), points.get(i));
        if (!edge.isHorizontal()) { edges.add(j, edge); }
        //From all points selects minimal and maximal Y.
        int minY = points.get(0).getY();
        int maxY = minY;
        for(i = 0; i< points.size(); i++) {
            if (minY > points.get(i).getY()) minY = points.get(i).getY();
            if (maxY < points.get(i).getY()) maxY = points.get(i).getY();
        }
        //Goes through all horizontals between minY and maxY
        for (int y = minY; y <= maxY; y++) {
            //Goes through all edges, saves x coordinate of intersection with the horizontal.
            List<Integer> intersections = new ArrayList<>();
            for (i = 0; i < edges.size(); i++) {
                if (edges.get(i).hasIntersection(y)) {
                    int x = edges.get(i).getIntersection(y);
                    intersections.add(x);
                }
            }
            //Sorts the intersections based on x - from left to right.
            Collections.sort(intersections);
            //Colors lines between intersects. First point must be on even index.
            for (i = 0; i <= intersections.size()-2; i+=2) {
                Line line = new Line(intersections.get(i), y, intersections.get(i + 1), y, fillColor);
                lineRasterizer.rasterize(line);
            }
        }
        //Highlights the border.
        for (i = 0; i < points.size()-1; i++) {
            lineRasterizer.rasterize(new Line(points.get(i), points.get(i + 1), borderColor));
        }
        lineRasterizer.rasterize(new Line(points.get(0), points.get(i), borderColor));
    }

}
