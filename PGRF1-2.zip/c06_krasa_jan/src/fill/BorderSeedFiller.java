//package fill;
//
//import model.Point;
//import rasterize.Raster;
//
//public class BorderSeedFiller implements Filler {
//
//    private final Raster raster;
//
//    private int borderColor;
//    private int fillColor;
//    private Point seed;
//
//    public BorderSeedFiller(Raster raster) {
//        this.raster = raster;
//        fillColor = 0xffffff;
//    }
//
//    public void setSeed(Point seed) {
//        this.seed = seed;
//        borderColor = raster.getPixel(seed.getX(), seed.getY());
//    }
//
//    public void setFillColor(int fillColor) {
//        this.fillColor = fillColor;
//    }
//
//    public void setBorderColor(int borderColor) {
//        this.borderColor = borderColor;
//    }
//
//    @Override
//    public void fill() {
//        borderSeedFill(seed.getX(), seed.getY());
//    }
//
//    private boolean rasterEdge(int x, int y) {
//        int rasterX = raster.getWidth();
//        int rasterY = raster.getHeight();
//
//        if ((x == 0)||(x == rasterX-1)) return true;
//        if ((y == 0)||(y == rasterY-1)) return true;
//        return false;
//    }
//
//    //  VM options -Xss80m
//    private void borderSeedFill(int x, int y) {
//        if ((raster.getPixel(x, y) != borderColor)&&(raster.getPixel(x, y) !=fillColor)) {
//            raster.setPixel(x, y, fillColor);
//            if (!rasterEdge(x,y)) borderSeedFill(x + 1, y); // rightwards
//            if (!rasterEdge(x,y)) borderSeedFill(x - 1, y); // leftwards
//            if (!rasterEdge(x,y)) borderSeedFill(x, y + 1); // downwards
//            if (!rasterEdge(x,y)) borderSeedFill(x, y - 1); // upwards
//        }
//    }
//
//}
