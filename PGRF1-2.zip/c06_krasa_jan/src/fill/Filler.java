package fill;

public interface Filler {

    void fill();

}
