package rasterize;

import java.awt.*;

public class FilledLineRasterizer extends LineRasterizer {

    public FilledLineRasterizer(Raster raster) {
        super(raster);
    }

    @Override //Rasterize using Bresenham's algorithm. - advantages: using just whole numbers, addition, extraction and multiplication by 2,
    //as such is fast and capable of running on simple hardware.
    public void rasterize(int x1, int y1, int x2, int y2, Color color) {

        float k = (y2 - y1) / (float) (x2 - x1);            //Computes the slope.
        float q = y1 - k * x1;                              //Computes y-itercept.

        if ((-1 < k)&&(k < 1)) {                            //Determines whether x or y is the leading axis.
            if (x1 > x2) {
                int x = x2;
                x2 = x1;
                x1 = x;
            }                              //Exchanges coordinates.
            for (int x = x1; x <= x2; x++) {                //X is the leading axis
                int y = (int) (k * x + q);
                raster.setPixel(x, y, color.getRGB());      //The Dashed effect achieved through simple up to 10 counting.
            }
        } else {
            if (y1 > y2) {
                int y = y2;
                y2 = y1;
                y1 = y;
            }                              //Exchanges coordinates.
            for (int y = y1; y <= y2; y++) {                //Y is the leading axis
                int x;
                if (x1 != x2) {x = (int) ((y - q) / k);}            //We can have a vertical line in which case we would divide by zero.
                else {x = x1;}
                raster.setPixel(x, y, color.getRGB());     //The Dashed effect achieved through simple up to 10 counting.
                    }
                }
            }
        }
//TODO Brensham obsahuje chybu, která souřadnici vyhodí do prdele. Bude třeba vytipovat sektor a opravit.
//TODO Po upravení bodu, přidání dalšího bodu mění již stávající bod. Ošetři.

//        int dx = Math.abs(x2 - x1);
//        int dy = Math.abs(y2 - y1);
//        int p = 2 * dy - dx;                    //Prediction - used for determining whether the secondary coordinates will change or not.
//        int x = x1, y = y1;
//        int moveX, moveY;                       //Changes X axis left to right, and Y axis down to top.
//
//        if (x1 < x2) moveX = 1; else moveX = -1; //Changes the semi-quadrant. X+ draws right, X- draws left.
//        if (y1 < y2) moveY = 1; else moveY = -1; //Changes the semi-quadrant. Y+ draws bottom, Y- draws top.
//
//        if (Math.abs(dx) >= Math.abs(dy)) {             //Determines which is the main axis. - Dx - x is main; Dy - y is main.
//            for (x = x1; x <= x2; x = x + moveX) {      //Cycle for creating the line, works at right side.
//                raster.setPixel(x, y, color.getRGB());
//                if (p >= 0) {
//                    y = y + moveY;
//                    p = p + 2 * dy - 2 * dx;
//                } else {
//                    p = p + 2 * dy;
//                }
//            }
//            for (x = x1; x >= x2; x = x + moveX) {      //Cycle for creating the line, works at left side.
//                raster.setPixel(x, y, color.getRGB());
//                if (p >= 0) {
//                    y = y + moveY;
//                    p = p + 2 * dy - 2 * dx;
//                } else {
//                    p = p + 2 * dy;
//                }
//            }
//        } else {
//            for (y = y1; y <= y2; y = y + moveY) {      //Cycle for creating the line, works at down side.
//                raster.setPixel(x, y, color.getRGB());
//                if(x1 !=x2) if (p >= 0) {               //If given a vertical line, just go through the setPixel.
//                    x = x + moveX;
//                    p = p + 2 * dx - 2 * dy;
//                } else {
//                    p = p + 2 * dx;
//                }
//            }
//            for (y = y1; y >= y2; y = y + moveY) {      //Cycle for creating the line, works at top side.
//                raster.setPixel(x, y, color.getRGB());
//                if(x1 !=x2) if (p >= 0) {               //If given a vertical line, just go through the setPixel.
//                    x = x + moveX;
//                    p = p + 2 * dx - 2 * dy;
//                } else {
//                    p = p + 2 * dx;
//                }
//            }
//       }
//
//   }
//}