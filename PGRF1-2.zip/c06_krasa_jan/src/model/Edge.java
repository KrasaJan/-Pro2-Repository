package model;

public class Edge {

    private int x1, y1, x2, y2;

    /**
     * @param p1 první koncový bod hrany
     * @param p2 druhý koncový bod hrany
     */
    public Edge(Point p1, Point p2) {
        this.x1 = p1.getX();
        this.y1 = p1.getY();
        this.x2 = p2.getX();
        this.y2 = p2.getY();
        orientate();
//        shorten();
    }

    /**
     * Zjistí, zda je hrana vodorovná
     *
     * @return true pokud je vodorovná, jinak false
     */
    public boolean isHorizontal() {
        return this.y1 == this.y2;
    }

    /**
     * Zorientuje hranu odshora dolů
     */
    public void orientate() {
        if (y1 > y2) {
            int aux1 = y2; int aux2 = x2;
            y2 = y1; x2 = x1;
            y1 = aux1; x1 = aux2;
        }
    }

    // Zkrátí hranu o 1 pixel
//    public void shorten() {
//
//        if (x1 != x2) {
//            float k = (y2 - y1) / (float) (x2 - x1);            //Computes the slope.
//            float q = y1 - k * x1;                              //Computes y-intercept.
//
//            if ((-1 < k) && (k < 1)) {
//                x2 = x2 -1;
//            } else {
//                y2 = y2 - 1;
//            }
//        } else y2 = y2-1;
//    }

    /**
     * Zjistí, zda existuje průsečík s touto hranou
     *
     * @param y y-ová souřadnice vodorovné přímky (řádek pixelů)
     * @return true, pokud v rozsahu této hrany existuje průsečík
     */
    public boolean hasIntersection(int y) {
        return (this.y1 < y) && (y <= this.y2);
    }

    /**
     * Vypočítá x-ovou souřadnici průsečíku s touto hranou
     *
     * @param y y-ová souřadnice vodorovné přímky (řádek pixelů)
     * @return vrátí x-ovou souřadnici průsečíku
     */
    public int getIntersection(int y) {
        if (x1!=x2){
            float k = (y2 - y1) / (float) (x2 - x1);            //Computes the slope.
            float q = y1 - k * x1;                              //Computes y-intercept.
            int x;

            x = (int) ((y - q) / k);
            return x;
        } else {
            return x1;
        }
    }

//
//      Zjistí na které straně přímky tvořené touto úsečkou se nachází bod z parametru
//
//      @param p bod pro zjištění
//      @return true, když je bod na "správné" straně - záleží na orientace a na výpočtu normály
//
//    public boolean isInside(Point p) {
//        // tečný vektor
//        Point t = new Point(x2 - x1, y2 - y1);
//
//        // normálový vektor
//        @SuppressWarnings("SuspiciousNameCombination")
//        Point n = new Point(t.y, -t.x);
////        Point n = new Point(-t.y, t.x);
//
//        // vektor k bodu
//        Point v = new Point(p.x - x1, p.y - y1);
//
//        return (v.x * n.x + v.y * n.y < 0);
//    }

    //TODO Not working. ¯\_(ツ)_/¯
//
//      Výpočet průsečíku dvou úseček.
//      První úsečka je daná instancí této třídy.
//      Druhá úsečka je dané dvěma body z parametrů funkce.
//
//      @param p1 první krajní bod druhé úsečky
//      @param p2 druhá krajní bod druhé úsečky
//      @return průsečík
//
//    public Point getIntersection(Point p1, Point p2) {
//        int x3 = p1.getX();
//        int y3 = p1.getY();
//        int x4 = p2.getX();
//        int y4 = p2.getY();
//        int x11, y11, x22, y22;
//        //First line
//        float k1 = (y2 - y1) / (float) (x2 - x1);            //Computes the slope.
//        float q1 = y1 - k1 * x1;                             //Computes y-intercept.
//        //Second line
//        float k2 = (y4 - y3) / (float) (x4 - x3);            //Computes the slope.
//        float q2 = y3 - k2 * x3;                             //Computes y-intercept.
//
//        if (x1 > x2) {
//            int x = x2;
//            x2 = x1;
//            x1 = x;
//            x = x4;
//            x4 = x3;
//            x3 = x;
//        }
//
//            for (x11 = x1; x11 <= x2; x11++) {
//                y11 = (int) (k1 * x11 + q1);
//                for (x22 = x3; x22 <= x4; x22++) {
//                    y22 = (int) (k2 * x22 + q2);
//                    if ((x11 == x22) && (y11 == y22)) {
//                        return new Point(x11, y11);
//                    }
//                }
//            }
//        System.out.print("fuck ");
//        return null;
//    }

}
