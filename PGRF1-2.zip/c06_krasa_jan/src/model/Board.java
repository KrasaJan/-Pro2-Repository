package model;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Board {

    private final List<model.Polygon> polygons;

    public Board() {
        this(new ArrayList<>());
    }

    public Board(List<model.Polygon> polygons) {
        this.polygons = polygons;
    }

    public void addPolygon(model.Polygon polygon) {
        addPolygons(polygon);
    }

    private void addPolygons(model.Polygon... polygonsToAdd) {
        polygons.addAll(Arrays.asList(polygonsToAdd.clone()));
    }

//    public void removePolygon(Polygon polygon) {
//        removePolygons(polygon);
//    }

//    private void removePolygons(Polygon... polygonsToRemove) {
//        polygons.removeAll(Arrays.asList(polygonsToRemove));
//    }

    public void removeALL() {
        polygons.clear();
    }

    public Polygon getPolygon(int i) {
        return this.polygons.get(i);
    }

    public int getSize() {
        return this.polygons.size();
    }

    public Color passColor(int index) {
        if (index%9 == 0) return Color.WHITE;
        if (index%9 == 1) return Color.GRAY;
        if (index%9 == 2) return Color.YELLOW;
        if (index%9 == 3) return Color.RED;
        if (index%9 == 4) return Color.ORANGE;
        if (index%9 == 5) return Color.CYAN;
        if (index%9 == 6) return Color.GREEN;
        if (index%9 == 7) return Color.MAGENTA;
        if (index%9 == 8) return Color.PINK;
        return null;
    }

}
